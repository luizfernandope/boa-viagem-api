package br.com.etechoracio.boa_viagem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoaViagemApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoaViagemApiApplication.class, args);
	}

}
