package br.com.etechoracio.boa_viagem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoaViagemApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
